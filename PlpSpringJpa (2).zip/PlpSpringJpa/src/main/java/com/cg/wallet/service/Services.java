package com.cg.wallet.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cg.wallet.bean.CustomerBean;
import com.cg.wallet.bean.TransactionsSummary;
import com.cg.wallet.dao.Dao;
import com.cg.wallet.dao.IDao;
import com.cg.wallet.exception.BalanceException;
import com.cg.wallet.exception.WalletException;

@Service("Service")
public class Services implements IService {

	@Autowired
	IDao dao;
	
	@Override
	public boolean validateChoice(String choice) {
		if (choice.matches(choice))
			return true;
		return false;
	}

	@Override
	public boolean validateAcntNo(String acnNto) {
		if (acnNto.matches(ACC_NO))
			return true;

		return false;
	}

	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(USER_NAME_PATTERN))
			return true;
		return false;
	}

	@Override
	public boolean validateMobileNo(String mobileNo) {
		if (mobileNo.matches(MOBILE_PATTERN))
			return true;
		return false;
	}

	@Override
	public boolean validateEmail(String email) {
		if (email.matches(EMAIL_PATTERN))
			return true;
		return false;
	}

	@Override
	public boolean validateAmount(String amount) {
		if (amount.matches(AMOUNT))
			return true;
		return false;
	}

	@Override
	public CustomerBean creatAccount(String name, String mobile, String email) throws WalletException, SQLException {
		int acntNo = (int) (Math.random() * 1000);
		return dao.creatAccount(acntNo, name, mobile, email);
	}

	@Override
	public boolean logIn(String acntNo) throws NumberFormatException, SQLException {
		return dao.logIn(acntNo);

	}

	@Override
	public Double showBalance(String acntNo) throws NumberFormatException, SQLException {
		return dao.showBalance(acntNo);
	}

	@Override
	public void deposit(String acntNo, String amount) throws NumberFormatException, SQLException {
		dao.deposit(acntNo, amount);
	}

	@Override
	public void withdraw(String acntNo, String amount) throws BalanceException, NumberFormatException, SQLException {
		dao.withdraw(acntNo, amount);
	}

	@Override
	public void fundTransfer(String sendAccNo, String recAcntNo, String amount)
			throws BalanceException, NumberFormatException, SQLException {
		dao.fundTransfer(sendAccNo, recAcntNo, amount);
	}

	@Override
	public List<TransactionsSummary> printTransactions(String acntNo) {
		return dao.printTransaction(acntNo);
	}

	@Override
	public CustomerBean showDetails(int acntNo) {
		return dao.showDetails(acntNo);
	}

}
