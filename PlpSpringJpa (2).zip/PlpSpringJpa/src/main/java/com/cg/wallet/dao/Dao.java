package com.cg.wallet.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.wallet.bean.CustomerBean;
import com.cg.wallet.bean.TransactionsSummary;
import com.cg.wallet.exception.BalanceException;
import com.cg.wallet.exception.WalletException;
import com.cg.wallet.service.Services;

@Repository("dao")
@Transactional
public class Dao implements IDao, ApplicationContextAware {

	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em;

	@Autowired
	private ApplicationContext context;

	public Dao() {

	}

	@Override
	public CustomerBean creatAccount(int acntNo, String name, String mobile, String email)
			throws WalletException, SQLException {
		try {

			CustomerBean cust = new CustomerBean(acntNo, name, Long.parseLong(mobile), email);

			em.persist(cust);

			TransactionsSummary trns = new TransactionsSummary(0, 0, "IB", cust);

			em.persist(trns);

			System.out.println("Customer added to database.");

			return em.find(CustomerBean.class, (acntNo));
		} catch (NumberFormatException e) {
			em.getTransaction().rollback();
		} finally {
		}
		return null;

	}

	@Override
	public boolean logIn(String acntNo) throws NumberFormatException, SQLException {

		CustomerBean cust = em.find(CustomerBean.class, Integer.parseInt(acntNo));
		if (cust == null) {
			return false;
		}
		return true;

	}

	@Override
	public Double showBalance(String acntNo) throws NumberFormatException, SQLException {
		CustomerBean bal = em.find(CustomerBean.class, Integer.parseInt(acntNo));
		return bal.getBalance();

	}

	@Override
	public void deposit(String acntNo, String amount) throws NumberFormatException, SQLException {

		try {
			CustomerBean bal = em.find(CustomerBean.class, Integer.parseInt(acntNo));
			double balance = bal.getBalance() + Double.parseDouble(amount);
			bal.setBalance(balance);
			em.merge(bal);
			TransactionsSummary trns = new TransactionsSummary(Integer.parseInt(amount), balance, "CR", bal);
			em.persist(trns);

		} catch (Exception e) {
			em.getTransaction().rollback();
		}

	}

	@Override
	public void withdraw(String acntNo, String amount) throws BalanceException, NumberFormatException, SQLException {

		CustomerBean bal = em.find(CustomerBean.class, Integer.parseInt(acntNo));

		if (bal.getBalance() > Double.parseDouble(amount)) {
			double balance = bal.getBalance() - Double.parseDouble(amount);
			bal.setBalance(balance);
			em.merge(bal);
			TransactionsSummary trns = new TransactionsSummary(Integer.parseInt(amount), balance, "WR", bal);
			em.persist(trns);

		} else {
			System.out.println("You have insufficient balance. Please add money first");
		}
	}

	@Override
	public void fundTransfer(String sendAccNo, String recAcntNo, String amount)
			throws BalanceException, NumberFormatException, SQLException {

		CustomerBean balRec = em.find(CustomerBean.class, Integer.parseInt(recAcntNo));
		if (balRec == null) {
			System.out.println("Receiver not found");
		}
		CustomerBean balSender = em.find(CustomerBean.class, Integer.parseInt(sendAccNo));

		if (balSender.getBalance() > Double.parseDouble(amount)) {

			double balanceSender = balSender.getBalance() - Double.parseDouble(amount);
			balSender.setBalance(balanceSender);
			em.merge(balSender);
			TransactionsSummary trnsSend = new TransactionsSummary(Double.parseDouble(amount), balanceSender, "FT",
					balSender);
			em.persist(trnsSend);

			double balanceReceiver = balRec.getBalance() + Double.parseDouble(amount);
			balRec.setBalance(balanceReceiver);
			em.merge(balRec);
			TransactionsSummary trnsRec = new TransactionsSummary(Double.parseDouble(amount), balanceReceiver, "FT",
					balRec);
			em.persist(trnsRec);

		} else {
			System.out.println("Insufficent balance");
		}

	}

	@Override
	public List<TransactionsSummary> printTransaction(String acntNo) {

		String strQuery1 = "SELECT trans FROM TransactionsSummary trans WHERE trans.customer.id=:acNo order by sr_no";
		TypedQuery<TransactionsSummary> query = em.createQuery(strQuery1, TransactionsSummary.class);
		query.setParameter("acNo", Integer.parseInt(acntNo));

		List<TransactionsSummary> transactions = query.getResultList();

		return transactions;

	}

	@Override
	public CustomerBean showDetails(int acntNo) {
		String strQuery2 = "SELECT user FROM CustomerBean user WHERE user.id=:acntNo";
		TypedQuery<CustomerBean> query = em.createQuery(strQuery2, CustomerBean.class);

		query.setParameter("acntNo", acntNo);

		return query.getSingleResult();
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		// TODO Auto-generated method stub

	}

}
