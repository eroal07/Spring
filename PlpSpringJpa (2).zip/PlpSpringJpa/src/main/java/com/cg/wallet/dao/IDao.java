package com.cg.wallet.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.wallet.bean.CustomerBean;
import com.cg.wallet.bean.TransactionsSummary;
import com.cg.wallet.exception.BalanceException;
import com.cg.wallet.exception.WalletException;

public interface IDao {

	CustomerBean creatAccount(int acntNo,String name, String mobile, String email) throws WalletException, SQLException;

	boolean logIn(String acntNo) throws NumberFormatException, SQLException;
	
	Double showBalance (String acntNo) throws NumberFormatException, SQLException;
	
	void deposit(String acntNo,String amount) throws NumberFormatException, SQLException;
	
	void withdraw(String acntNo,String amount) throws BalanceException, NumberFormatException, SQLException;
	
	void fundTransfer(String sendAccNo,String recAcntNo, String amount) throws BalanceException, NumberFormatException, SQLException;
	
	List<TransactionsSummary> printTransaction(String acntNo);
	
	CustomerBean showDetails (int acntNo);
	
	

}
