package com.cg.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeTest {
	
	@Test
	public void testEmployee() {		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
	}
	

}
