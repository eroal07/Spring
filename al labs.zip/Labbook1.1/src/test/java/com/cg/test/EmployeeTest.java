package com.cg.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.ioc.Employee;

public class EmployeeTest {

	@Test
	public void testEmployee() {

		ApplicationContext ctx1 = new ClassPathXmlApplicationContext("employee.xml");
		Employee emp = (Employee) ctx1.getBean("employeebean");
		System.out.println("Employee Details");
		System.out.println("----------------------------------");
		System.out.println(emp);
	}

}
