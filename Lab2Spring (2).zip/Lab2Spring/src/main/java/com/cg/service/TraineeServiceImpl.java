package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ctr.Trainee;
import com.cg.repo.TraineeRepo;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeRepo repo;

	@Override
	public void saveTrainee(Trainee a) {
		repo.save(a);
	}

	@Override
	public Trainee getTrainee(int traineeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteTrainee(int traineeId) {
		
	}

	@Override
	public void updateTrainee(Trainee a) {
		
	}

	@Override
	public List<Trainee> getAllTrainee() {
		return null;
	}

}