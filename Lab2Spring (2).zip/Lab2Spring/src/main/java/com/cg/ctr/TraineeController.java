package com.cg.ctr;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.service.TraineeService;

@Controller
public class TraineeController {
	@Autowired
	TraineeService service;

	@RequestMapping(value = "/")
	public String home(Model m) {
		m.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping(value = "checkLogin")
	public String checkLogin(Login log) {

		// Logic to validate userName and password against database
		if (log.getUserName().equals("admin") && log.getPassword().equals("123456")) {
			return "loginSuccess";
		} else {
			return "login";
		}
	}

	@RequestMapping(value = "/Add")
	public String addTrainee(Model m) {
		m.addAttribute("trainee", new Trainee());
		return "AddTrainee";

	}
	
	@RequestMapping(path="/saveDetails")
	public String dataAdd(@ModelAttribute("trainee") Trainee trainee,Model m) {
		System.out.println(trainee);
		service.saveTrainee(trainee);
		
		return "loginSuccess";
		
	}
}
