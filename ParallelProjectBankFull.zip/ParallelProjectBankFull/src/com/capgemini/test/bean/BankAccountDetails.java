package com.capgemini.test.bean;

public class BankAccountDetails {

	 private int accno;
	 private String accname;
	 private String address;
	 private String phoneno;
	 private double balance;
	 private int amount;
	
	
	
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getAccName() {
		return accname;
	}
	public void setAccName(String accName) {
		this.accname = accName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	@Override
	public String toString() {
		return "Customer Details Are: [Name: " + accname + "\nAddress: " +address+ "\nPhone no: " +phoneno+ "\nAcc No: " +accno+ "\nBalance" +balance;
	}
	
	
}
