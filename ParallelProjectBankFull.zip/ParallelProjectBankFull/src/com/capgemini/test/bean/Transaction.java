package com.capgemini.test.bean;

public class Transaction {

	private String type;
	private int amount;
	double balance;
	
	public Transaction() {
	}

	public Transaction(String type, int amount, double balance) {

		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}

	public String print() {
		return type + "\t " + amount + "\t" + balance;
	}
}
	
	
	
