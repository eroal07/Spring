package com.capgemini.test.exception;

public class CRAException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CRAException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CRAException() {
		super();
		// TODO Auto-generated construtor stub
	}
	
	
	
	
	

}
