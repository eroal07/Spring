package com.capgemini.test.service;

import java.sql.SQLException;
import java.util.Map;

import com.capgemini.test.bean.BankAccountDetails;
import com.capgemini.test.doa.DoaBankClass;
import com.capgemini.test.doa.DoaSQLclass;
import com.capgemini.test.exception.CRAException;

public class BankServiceClass implements BankServiceInterface {

	DoaBankClass doabanktoserv = new DoaBankClass();
	BankAccountDetails bankdetserv = new BankAccountDetails();

	public boolean validateChoice(String userChoice) {
		if (userChoice.matches(userChoicePattern))
			return true;
		else
			return false;
	}

	public boolean validateUserName(String userName) {
		if (userName.matches(userNamePattern))
			return true;
		else
			return false;
	}

	public boolean validateAddress(String userAddress) {
		if (userAddress.matches(userAddressPattern))
			return true;
		else
			return false;
	}

	public boolean validateEmail(String userEmail) {
		if (userEmail.matches(userEmailPattern))
			return true;
		else
			return false;
	}

	public boolean validatePhone(String userPhone) {
		if (userPhone.matches(userPhonepattern))
			return true;
		else
			return false;

	}

	public boolean validateUserserviceChoice(String userchoice) {
		if (userchoice.matches(userServiceChoice))
			return true;
		else
			return false;
	}

	// Create Account setter

	// doa methods

	DoaSQLclass jdbcdao = new DoaSQLclass();

	/*
	 * public void storeIntoMap(BankAccountDetails bankdetails) {
	 * doabanktoserv.storeIntoMap(bankdetails);
	 * 
	 * }
	 */

	public void storeIntoMap(BankAccountDetails bankdetails)
			throws ClassNotFoundException, CRAException, SQLException {
		jdbcdao.storeIntoMap(bankdetails);
	}

	public Map<Integer, BankAccountDetails> displayBankAccountDetails() {
		return doabanktoserv.displayBankAccountDetails();
	}

	@Override
	public void showBalance() {
		doabanktoserv.showBalance();
	}

	@Override
	public void deposit(int amount) {
		doabanktoserv.storeBalance(amount);
	}

	public void withdraw(int amount) {
		doabanktoserv.withdrawBalance(amount);
	}

	public void fundTransfer(int amount) {
		doabanktoserv.fundTransfer(amount);
	}

	@Override
	public void creatAccount(String accname, String address, String phoneno) {
		doabanktoserv.creatAccount(accname, address, phoneno);

	}

	@Override
	public void summary() {
		doabanktoserv.summary();
	}

}
