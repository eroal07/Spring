package com.capgemini.test.service;

import java.sql.SQLException;
import java.util.Map;

import com.capgemini.test.bean.BankAccountDetails;
import com.capgemini.test.exception.CRAException;

public interface BankServiceInterface {

	String userChoicePattern = "[1-2]{1}";
	String userNamePattern = "[A-Z a-z]{2,20}";
	String userAddressPattern = "[A-z]{5,20}";
	String userEmailPattern = "[A-z]{5,15}[@]{1}[A-z]{3,15}[.]{1}[c,o,m]{3}";
	String userPhonepattern = "[0-9]{10}";
	String userServiceChoice = "[1-6]{1}";

	boolean validateChoice(String userChoice);

	boolean validateUserName(String userName);

	boolean validateAddress(String userAddress);

	boolean validateEmail(String userEmail);

	boolean validatePhone(String userPhone);

	boolean validateUserserviceChoice(String userchoice);

	void showBalance();

	void deposit(int amount);

	void withdraw(int amount);

	void fundTransfer(int amount);

	public void creatAccount(String accname, String address, String phoneno);

	void summary();

	void storeIntoMap(BankAccountDetails bankdetails)
			throws ClassNotFoundException, CRAException, SQLException;

	Map<Integer, BankAccountDetails> displayBankAccountDetails();
}
