package com.capgemini.test.doa;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.test.bean.BankAccountDetails;
import com.capgemini.test.bean.Transaction;

public class DoaBankClass implements DoaBankInterface {

	Map<Integer, BankAccountDetails> bankmap = new HashMap<Integer, BankAccountDetails>();

	Map<Integer, Double> bankbal = new HashMap<Integer, Double>();
	Transaction[] txns;
	int idx;

	BankAccountDetails bankobj = new BankAccountDetails();

	public void storeIntoMap(BankAccountDetails bankdetails) {
		bankmap.put(bankdetails.getAccno(), bankdetails);

	}

	public Map<Integer, BankAccountDetails> displayBankAccountDetails() {

		return bankmap;
	}

	public void storeBalance(int amount) {

		bankobj.setBalance(bankobj.getBalance() + amount);
		bankbal.put(bankobj.getAccno(), bankobj.getBalance());
		txns[idx++] = new Transaction("CR", amount, bankobj.getBalance());
	}

	public void withdrawBalance(int amount) {
		if (amount <= bankobj.getBalance()) {
			bankobj.setBalance(bankobj.getBalance() - amount);
			bankbal.put(bankobj.getAccno(), bankobj.getBalance());
			txns[idx++] = new Transaction("WR", amount, bankobj.getBalance());
		} else
			System.out.println("insufficient balance");
	}

	public void fundTransfer(int amount) {
		if (amount <= bankobj.getBalance()) {
			bankobj.setBalance(bankobj.getBalance() - amount);
			bankbal.put(bankobj.getAccno(), bankobj.getBalance());
			txns[idx++] = new Transaction("FT", amount, bankobj.getBalance());
		} else
			System.out.println("insufficient balance to transfer");
	}

	public void creatAccount(String accname, String address, String phoneno) {
		bankobj.setAccName(accname);
		bankobj.setAddress(address);
		bankobj.setPhoneno(phoneno);

		txns = new Transaction[10];
		txns[idx++] = new Transaction("CR", bankobj.getAmount(),
				bankobj.getBalance());

	}

	@Override
	public void showBalance() {

		System.out.println(bankobj.getBalance());

	}

	@Override
	public void summary() {
		for (int i = 0; i < idx; i++)
			System.out.println(txns[i].print());

	}

}
