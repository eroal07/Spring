package com.capgemini.test.doa;

import java.sql.SQLException;

import com.capgemini.test.bean.BankAccountDetails;
import com.capgemini.test.exception.CRAException;

public interface DaoSQLInterface {
	
	void storeIntoMap(BankAccountDetails bankdetails) throws CRAException, SQLException, ClassNotFoundException ;
	
}
