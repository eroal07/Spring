package com.capgemini.test.doa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import com.capgemini.test.bean.BankAccountDetails;
import com.capgemini.test.exception.CRAException;
import com.capgemini.test.utility.JdbcUtility;

public class DoaSQLclass implements DaoSQLInterface {

	Connection connection = null;
	PreparedStatement statement = null;

	/**
	 * method name : insertCustomerDetail argument : CabRequest class object
	 * return type : int author : Capgemini date : 19-02-2019
	 * 
	 * description : This method will take the CabRequest Class(in bean package)
	 * object as an argument and returns the generated id to the user
	 * 
	 * @throws ClassNotFoundException
	 */
	@Override
	public void storeIntoMap(BankAccountDetails bankdetails)
			throws CRAException, SQLException, ClassNotFoundException {

		connection = JdbcUtility.getConnection();

		try {
			statement = connection.prepareStatement(QuerryMap.insertDetails);

			statement.setString(1, bankdetails.getAccName());
			statement.setString(2, bankdetails.getAddress());
			statement.setString(3, bankdetails.getPhoneno());
			statement.setLong(4, bankdetails.getAmount());

			statement.executeUpdate();

		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);

		} finally {

			try {
				statement.close();
			} catch (SQLException e) {

				throw new CRAException("unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {

				throw new CRAException("unable to close connection object");
			}
		}

	}

}
