package com.capgemini.test.doa;

import java.sql.SQLException;
import java.util.Map;

import com.capgemini.test.bean.BankAccountDetails;
import com.capgemini.test.exception.CRAException;

public interface DoaBankInterface {

	void storeIntoMap(BankAccountDetails bankdetails) throws CRAException, SQLException, ClassNotFoundException;

	Map<Integer, BankAccountDetails> displayBankAccountDetails();

	void showBalance();

	public void storeBalance(int amount)throws CRAException, SQLException ;

	public void withdrawBalance(int amount);

	public void fundTransfer(int amount);

	void creatAccount(String accname, String address, String phoneno);

	void summary();

}
