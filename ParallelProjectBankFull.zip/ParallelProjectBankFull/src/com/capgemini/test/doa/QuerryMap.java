package com.capgemini.test.doa;

public interface QuerryMap {

	String insertDetails = "insert into bankdetails"
			+ "(accname,address,phoneno,amount) "
			+ "values"

			+ "(?,?,?,?)";;

	/*
	 * Insert into patient values (124,�patient
	 * 2�,13,9898989898,�unwell�,sysdate
	 */

	String selectGeneratedId = "select seq_request_id.CURRVAL from dual";
}
