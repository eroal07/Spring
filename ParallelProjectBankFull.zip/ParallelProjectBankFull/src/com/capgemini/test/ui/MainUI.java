package com.capgemini.test.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.test.bean.BankAccountDetails;
import com.capgemini.test.bean.Transaction;
import com.capgemini.test.exception.CRAException;
import com.capgemini.test.service.BankServiceClass;
import com.capgemini.test.service.BankServiceInterface;

public class MainUI {

	public static void main(String[] args) throws IOException {

		BankServiceInterface bankInterface = new BankServiceClass();
		Scanner scan = new Scanner(System.in);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BankAccountDetails bankdetailsbean = new BankAccountDetails();

		String choice;
		String accname;
		String address;
		String phoneno;
		int amount;
		int servicechoice;
		// Transaction

		System.out.println("-------HdfcBank welcomes you------");

		while (true) {
			System.out.println("Enter your Choice: ");
			System.out.println("1.Create Account");
			System.out.println("2.Exit");

			choice = scan.next();

			boolean isValidchoice = bankInterface.validateChoice(choice);

			if (isValidchoice)
				break;
			System.out.println("Enter valid choice either 1 or 2");
		}
		if (2 == Integer.parseInt(choice)) {
			System.out.println("you have now exited the application!");
			System.exit(0);
		}
		System.out.println("---Enter Details--- \n");

		while (true) {
			System.out.println("Enter your name:");
			accname = br.readLine();

			boolean isValidName = bankInterface.validateUserName(accname);
			/*
			 * if(isValid) System.out.println("right"); else
			 * System.out.println("wrong");
			 */
			if (isValidName)
				break;
			System.out.println("Name invalid, Enter name again.");
		}

		while (true) {
			System.out.println("Enter Address");
			address = br.readLine();

			boolean isValidAddress = bankInterface.validateAddress(address);

			if (isValidAddress)
				break;
			System.out.println("Adress invalid, Enter Address again.");
		}

		while (true) {
			System.out.println("Enter phone no:");
			phoneno = scan.next();

			boolean isValidPhone = bankInterface.validatePhone(phoneno);

			if (isValidPhone)
				break;
			System.out.println("Phone no is invalid");
		}

		int accno = (int) (Math.random() * 50 + 1);
		System.out.println("Customer information saved successfully.\n");
		System.out.println("Your account no. is :" + accno);

		bankdetailsbean.setAccName(accname);
		bankdetailsbean.setAddress(address);
		bankdetailsbean.setPhoneno(phoneno);
		bankdetailsbean.setAccno(accno);

		bankInterface.creatAccount(accname, address, phoneno);

		try {
			bankInterface.storeIntoMap(bankdetailsbean);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CRAException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(bankInterface.displayBankAccountDetails());

		while (true) {
			System.out.println("-----Choose the service-----\n");

			System.out.println("1.Show Balance");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Fund Transfer");
			System.out.println("5.Print Transaction");
			System.out.println("6.Exit");
			System.out.println("Enter your choice.");

			servicechoice = scan.nextInt();

			switch (servicechoice) {
			case 1:
				System.out.println("-------");
				System.out.println("Your balance is");
				bankInterface.showBalance();
				break;

			case 2:

				System.out.println("Enter amount to deposit: ");
				amount = scan.nextInt();

				bankdetailsbean.setAmount(amount);
				bankInterface.deposit(amount);

				break;

			case 3:

				System.out.println("Enter amount to withdraw:");
				amount = scan.nextInt();
				bankdetailsbean.setAmount(amount);
				bankInterface.withdraw(amount);

				break;

			case 4:
				System.out.println("------Fund transfer-----");
				System.out.println("Enter Acc no to transfer fund:");
				int rAccno = scan.nextInt();
				System.out.println("Enter amount to transfer:");
				amount = scan.nextInt();
				bankdetailsbean.setAmount(amount);
				bankInterface.fundTransfer(amount);

				break;
			case 5:
				System.out.println("Print Transaction");
				bankInterface.summary();
				break;

			case 6:
				System.out.println("you have now exited the application!");
				System.exit(0);

			default:
				System.out
						.println("Enter valid choice i.e choose a number form 1-6");

			}
		}

	}
}
